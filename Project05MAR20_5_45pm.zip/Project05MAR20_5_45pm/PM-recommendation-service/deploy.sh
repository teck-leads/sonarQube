if sudo docker login -u DTNA_CVD_s_GitToHub -p $1 docker-registry-dtna.app.corpintra.net; then
    echo "logged in"
else
    echo "error logging in"
    exit 1
fi
if sudo docker build -f Dockerfile -t $2:$3 .; then
    echo "container built"
else
    sudo docker logout docker-registry-dtna.app.corpintra.net
    echo "error"
    exit 1
fi
sudo docker tag $2:$3 docker-registry-dtna.app.corpintra.net/library/$2:$3
sudo docker push docker-registry-dtna.app.corpintra.net/library/$2:$3
sudo docker rmi -f $(sudo docker images -q)
sudo docker logout docker-registry-dtna.app.corpintra.net
echo "{  "application": "$4",  "applicationProcess": "deploy specific version","environment": "DEV","versions": [{"component": "$2","version": "$3"}]}" > "$4.json"