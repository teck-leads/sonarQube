package com.dtna.owl.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.dtna.owl.commons.DBQueries;
import com.dtna.owl.model.ConversionRate;
import com.dtna.owl.model.DifntlPickList;
import com.dtna.owl.model.EnginePickList;
import com.dtna.owl.model.ModelPickList;
import com.dtna.owl.model.MpgPickList;
import com.dtna.owl.model.MpgVoctn;
import com.dtna.owl.model.MviInspePickList;
import com.dtna.owl.model.NumAxlesPickList;
import com.dtna.owl.model.NumWhelSrvcesPickList;
import com.dtna.owl.model.PickListParent;
import com.dtna.owl.model.PlandYrsOfSrvcPickList;
import com.dtna.owl.model.PtoHrsPickList;
import com.dtna.owl.model.RecommdOutput;
import com.dtna.owl.model.RecommendationInput;
import com.dtna.owl.model.TranMsnPickList;
import com.dtna.owl.model.VoctnMpg;
import com.dtna.owl.model.VoctnPickList;

@Repository
public class RecommendationDaoImpl implements RecommendationDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	//private static List<PickListParent> statallPickListParents=getAllPickList();

	@Override
	public List<EnginePickList> getEngineList() throws Exception {
		try {
			String ENG = "Engine";
			List<EnginePickList> engines = new ArrayList<EnginePickList>();
//			Object[] params = { ENG };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<EnginePickList>>() {
//
//				@Override
//				public List<EnginePickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						EnginePickList eng = new EnginePickList();
//						eng.setValue(rs.getString("RT_LKP_VALU"));
//						eng.setDesc(rs.getString("RT_LKP_DESC"));
//
//						engines.add(eng);
//					}
//					return engines;
//				}
//			});

			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(ENG)) {
					EnginePickList en=new EnginePickList();
					en.setValue(all.getValue());
					en.setDesc(all.getDesc());
					engines.add(en);
				}
			});
			
			return engines;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<ModelPickList> getModelList(String engine) throws Exception {
		try {
			String MDL = "Model";
			List<ModelPickList> models = new ArrayList<ModelPickList>();
//			Object[] params = { MDL,engine };
//			jdbcTemplate.query(DBQueries.GET_MODL_TRASM, params, new ResultSetExtractor<List<ModelPickList>>() {
//
//				@Override
//				public List<ModelPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						ModelPickList mdl = new ModelPickList();
//						mdl.setValue(rs.getString("RT_LKP_VALU"));
//						mdl.setDesc(rs.getString("RT_LKP_DESC"));
//
//						models.add(mdl);
//					}
//					return models;
//				}
//			});

			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if (all.getLkpTyp().equals(MDL) && all.getParentTyp().equalsIgnoreCase(engine)) {
					ModelPickList mdl = new ModelPickList();
					mdl.setValue(all.getValue());
					mdl.setDesc(all.getDesc());
					models.add(mdl);
				}
			});
			
			return models;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<TranMsnPickList> getTranMsnList(String modelValue) throws Exception {
		try {
			String TRNMSN = "Transmission";
			List<TranMsnPickList> tranMsns = new ArrayList<TranMsnPickList>();
//			Object[] params = { TRNMSN,modelValue };
//			jdbcTemplate.query(DBQueries.GET_MODL_TRASM, params, new ResultSetExtractor<List<TranMsnPickList>>() {
//
//				@Override
//				public List<TranMsnPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						TranMsnPickList tranMsn = new TranMsnPickList();
//						tranMsn.setValue(rs.getString("RT_LKP_VALU"));
//						tranMsn.setDesc(rs.getString("RT_LKP_DESC"));
//
//						tranMsns.add(tranMsn);
//					}
//					return tranMsns;
//				}
//			});
			
			
			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(TRNMSN)) {
					TranMsnPickList tranmsn=new TranMsnPickList();
					tranmsn.setValue(all.getValue());
					tranmsn.setDesc(all.getDesc());
					tranMsns.add(tranmsn);
				}
			});

			return tranMsns;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<DifntlPickList> getDifntlList() throws Exception {
		try {
			String TRNMSN = "Differential";
			List<DifntlPickList> difntls = new ArrayList<DifntlPickList>();
//			Object[] params = { TRNMSN };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<DifntlPickList>>() {
//
//				@Override
//				public List<DifntlPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						DifntlPickList difntl = new DifntlPickList();
//						difntl.setValue(rs.getString("RT_LKP_VALU"));
//						difntl.setDesc(rs.getString("RT_LKP_DESC"));
//
//						difntls.add(difntl);
//					}
//					return difntls;
//				}
//			});

			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(TRNMSN)) {
					DifntlPickList difntl=new DifntlPickList();
					difntl.setValue(all.getValue());
					difntl.setDesc(all.getDesc());
					difntls.add(difntl);
				}
			});

			return difntls;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<VoctnPickList> getVoctnPickListList() throws Exception {
		try {
			String VOCTN = "Vocation";
			List<VoctnPickList> voctnPicks = new ArrayList<VoctnPickList>();
//			Object[] params = { VOCTN };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<VoctnPickList>>() {
//
//				@Override
//				public List<VoctnPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						VoctnPickList voctnPick = new VoctnPickList();
//						voctnPick.setValue(rs.getString("RT_LKP_VALU"));
//						voctnPick.setDesc(rs.getString("RT_LKP_DESC"));
//
//						voctnPicks.add(voctnPick);
//					}
//					return voctnPicks;
//				}
//			});
			
			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(VOCTN)) {
					VoctnPickList voctnPick=new VoctnPickList();
					voctnPick.setValue(all.getValue());
					voctnPick.setDesc(all.getDesc());
					voctnPicks.add(voctnPick);
				}
			});

			return voctnPicks;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<MpgPickList> getMpgPickListList() throws Exception {
		try {
			String MPG = "MPG";
			List<MpgPickList> mpgPicks = new ArrayList<MpgPickList>();
//			Object[] params = { MPG };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<MpgPickList>>() {
//
//				@Override
//				public List<MpgPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						MpgPickList mpgPck = new MpgPickList();
//						mpgPck.setValue(rs.getString("RT_LKP_VALU"));
//						mpgPck.setDesc(rs.getString("RT_LKP_DESC"));
//
//						mpgPicks.add(mpgPck);
//					}
//					return mpgPicks;
//				}
//			});
			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(MPG)) {
					MpgPickList mpgPck=new MpgPickList();
					mpgPck.setValue(all.getValue());
					mpgPck.setDesc(all.getDesc());
					mpgPicks.add(mpgPck);
				}
			});

			return mpgPicks;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<PtoHrsPickList> getPtoHrsPickListList() throws Exception {
		try {
			String PTO = "PTO_HRS";
			List<PtoHrsPickList> ptoHrs = new ArrayList<PtoHrsPickList>();
			Object[] params = { PTO };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<PtoHrsPickList>>() {
//
//				@Override
//				public List<PtoHrsPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						PtoHrsPickList ptoHr = new PtoHrsPickList();
//						ptoHr.setValue(rs.getString("RT_LKP_VALU"));
//						ptoHr.setDesc(rs.getString("RT_LKP_DESC"));
//
//						ptoHrs.add(ptoHr);
//					}
//					return ptoHrs;
//				}
//			});
			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(PTO)) {
					PtoHrsPickList ptoHr=new PtoHrsPickList();
					ptoHr.setValue(all.getValue());
					ptoHr.setDesc(all.getDesc());
					ptoHrs.add(ptoHr);
				}
			});
			

			return ptoHrs;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<PlandYrsOfSrvcPickList> getPlndYrsOfSrvcPickListList() throws Exception {
		try {
			String PLND_YRS = "PLND_YR_SRVC";
			List<PlandYrsOfSrvcPickList> pndYrsOfSrvcs = new ArrayList<PlandYrsOfSrvcPickList>();
//			Object[] params = { PLND_YRS };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<PlandYrsOfSrvcPickList>>() {
//
//				@Override
//				public List<PlandYrsOfSrvcPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						PlandYrsOfSrvcPickList pndYrsOfSrvc = new PlandYrsOfSrvcPickList();
//						pndYrsOfSrvc.setValue(rs.getString("RT_LKP_VALU"));
//						pndYrsOfSrvc.setDesc(rs.getString("RT_LKP_DESC"));
//
//						pndYrsOfSrvcs.add(pndYrsOfSrvc);
//					}
//					return pndYrsOfSrvcs;
//				}
//			});
			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(PLND_YRS)) {
					PlandYrsOfSrvcPickList pndYrsOfSrvc=new PlandYrsOfSrvcPickList();
					pndYrsOfSrvc.setValue(all.getValue());
					pndYrsOfSrvc.setDesc(all.getDesc());
					pndYrsOfSrvcs.add(pndYrsOfSrvc);
				}
			});

			return pndYrsOfSrvcs;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<MviInspePickList> getMviInspePickList() throws Exception {
		try {
			String MVI_INSPEC = "MVI_INSPEC";
			List<MviInspePickList> mviInspectns = new ArrayList<MviInspePickList>();
//			Object[] params = { MVI_INSPEC };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<MviInspePickList>>() {
//
//				@Override
//				public List<MviInspePickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						MviInspePickList mviInspectn = new MviInspePickList();
//						mviInspectn.setValue(rs.getString("RT_LKP_VALU"));
//						mviInspectn.setDesc(rs.getString("RT_LKP_DESC"));
//
//						mviInspectns.add(mviInspectn);
//					}
//					return mviInspectns;
//				}
//			});
			
			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(MVI_INSPEC)) {
					MviInspePickList mviInspectn=new MviInspePickList();
					mviInspectn.setValue(all.getValue());
					mviInspectn.setDesc(all.getDesc());
					mviInspectns.add(mviInspectn);
				}
			});

			return mviInspectns;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<NumWhelSrvcesPickList> getNumWhelSrvcesPickList() throws Exception {
		try {
			String NUM_WHEL_SRVCS = "NUM_WHEL_SRVCS";
			List<NumWhelSrvcesPickList> numWhelSrvcs = new ArrayList<NumWhelSrvcesPickList>();
//			Object[] params = { NUM_WHEL_SRVCS };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<NumWhelSrvcesPickList>>() {
//
//				@Override
//				public List<NumWhelSrvcesPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						NumWhelSrvcesPickList numWhelSrvc = new NumWhelSrvcesPickList();
//						numWhelSrvc.setValue(rs.getString("RT_LKP_VALU"));
//						numWhelSrvc.setDesc(rs.getString("RT_LKP_DESC"));
//
//						numWhelSrvcs.add(numWhelSrvc);
//					}
//					return numWhelSrvcs;
//				}
//			});
			
			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(NUM_WHEL_SRVCS)) {
					NumWhelSrvcesPickList numWhelSrvc=new NumWhelSrvcesPickList();
					numWhelSrvc.setValue(all.getValue());
					numWhelSrvc.setDesc(all.getDesc());
					numWhelSrvcs.add(numWhelSrvc);
				}
			});

			return numWhelSrvcs;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<NumAxlesPickList> getNumAxlesPickList() throws Exception {
		try {
			String NUM_AXLES = "NUM_AXLES";
			List<NumAxlesPickList> numAxless = new ArrayList<NumAxlesPickList>();
//			Object[] params = { NUM_AXLES };
//			jdbcTemplate.query(DBQueries.GET_PCKLIST, params, new ResultSetExtractor<List<NumAxlesPickList>>() {
//
//				@Override
//				public List<NumAxlesPickList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//					while (rs.next()) {
//						NumAxlesPickList numAxles = new NumAxlesPickList();
//						numAxles.setValue(rs.getString("RT_LKP_VALU"));
//						numAxles.setDesc(rs.getString("RT_LKP_DESC"));
//
//						numAxless.add(numAxles);
//					}
//					return numAxless;
//				}
//			});
			
			List<PickListParent> allPickList = getAllPickList();
			allPickList.forEach(all->{
				if(all.getLkpTyp().equals(NUM_AXLES)) {
					NumAxlesPickList numAxles=new NumAxlesPickList();
					numAxles.setValue(all.getValue());
					numAxles.setDesc(all.getDesc());
					numAxless.add(numAxles);
				}
			});

			return numAxless;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<RecommdOutput> getRecommdOutput(String bseMdlCde, int servIntervl, int srvcYr) throws Exception {
		try {
			String PROD_TYP_CD = "ENGINE";
			List<RecommdOutput> recmdOutputs = new ArrayList<RecommdOutput>();
			Object[] params = { PROD_TYP_CD,bseMdlCde,srvcYr,servIntervl };
			jdbcTemplate.query(DBQueries.CAL_RECMD, params, new ResultSetExtractor<List<RecommdOutput>>() {

				@Override
				public List<RecommdOutput> extractData(ResultSet rs) throws SQLException, DataAccessException {

					while (rs.next()) {
						RecommdOutput recmdOutput = new RecommdOutput();
						recmdOutput.setServcTyp(rs.getString("SRVC_TYP"));
						recmdOutput.setSrvcFreq(String.valueOf(rs.getInt("SRVC_FREQ")));
						recmdOutput.setSrvcPer(rs.getString("SRVC_PER"));
						recmdOutputs.add(recmdOutput);
					
					}
					return recmdOutputs;
				}
			});

			return recmdOutputs;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public VoctnMpg getVoctnMpg(String baseMdlCd, String voctn) throws Exception {
		try {
			String PROD_TYP_CD = "ENGINE";
			Object[] params= {PROD_TYP_CD,baseMdlCd,voctn};
			VoctnMpg voctnMpg=new VoctnMpg();
			jdbcTemplate.query(DBQueries.VOCATN, params, new ResultSetExtractor<VoctnMpg>() {

				@Override
				public VoctnMpg extractData(ResultSet rs) throws SQLException, DataAccessException {
					while(rs.next()) {
						voctnMpg.setMpgVal1(rs.getDouble("MPG_VAL1"));
						voctnMpg.setMpgVal2(rs.getDouble("MPG_VAL2"));
						voctnMpg.setSrvcIntrvl1(rs.getInt("SRVC_INTRV_VAL1"));
						voctnMpg.setSrvcIntrvl2(rs.getInt("SRVC_INTRV_VAL2"));
					}
					return voctnMpg;
				}
			});
			return voctnMpg;
		} catch (DataAccessException e) {
			throw e;
		}
	}



	@Override
	public ConversionRate getConvertionRate(RecommendationInput recommendationInput) throws Exception {
		try {
			String PROD_TYP_CD = "ENGINE";
			ConversionRate conversionRate=new ConversionRate();
			Object[] params= {PROD_TYP_CD,recommendationInput.getEngine(),recommendationInput.getVocation()};
			jdbcTemplate.query(DBQueries.CNVRSN_RATE, params, new ResultSetExtractor<ConversionRate>() {

				@Override
				public ConversionRate extractData(ResultSet rs) throws SQLException, DataAccessException {
					while(rs.next()) {
						conversionRate.setPtoCnvrtVal1Usa(rs.getInt("PTO_CNVRT_RT_VAL1"));
						conversionRate.setPtoCnvrtVal2Canada(rs.getInt("PTO_CNVRT_RT_VAL2"));
						
					}
					return conversionRate;
				}
			});
			return conversionRate;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public List<PickListParent> getAllPickList() throws Exception {
		try {
			Object[] params = {};
			List<PickListParent> allPickListParents = new ArrayList<PickListParent>();
			jdbcTemplate.query("SELECT RT_LKP_VALU, RT_LKP_DESC,RT_LKP_TYP,PARENT_LKP_VALU FROM OWL.PM_RT_LKP_VALUE", params,
					new ResultSetExtractor<List<PickListParent>>() {

						@Override
						public List<PickListParent> extractData(ResultSet rs) throws SQLException, DataAccessException {
							while (rs.next()) {
								PickListParent pikLst = new PickListParent();
								pikLst.setValue(rs.getString("RT_LKP_VALU"));
								pikLst.setDesc(rs.getString("RT_LKP_DESC"));
								pikLst.setLkpTyp(rs.getString("RT_LKP_TYP"));
								pikLst.setParentTyp(rs.getString("PARENT_LKP_VALU"));
								allPickListParents.add(pikLst);

							}
							return allPickListParents;
						}
					});
			return allPickListParents;
		} catch (Exception e) {
			throw e;
		}
	}



	@Override
	public MpgVoctn getMpgVoctn(String baseMdlCd, String mpgval, String domicile) throws Exception {
		try {
			String PROD_TYP_CD = "ENGINE";
			Object[] params= {PROD_TYP_CD,baseMdlCd,mpgval};
			MpgVoctn mpgVoctn=new MpgVoctn();
			
			if(domicile.equalsIgnoreCase("usa")) {
				jdbcTemplate.query(DBQueries.MPG_VOC_USA,params, new ResultSetExtractor<MpgVoctn>() {

					@Override
					public MpgVoctn extractData(ResultSet rs) throws SQLException, DataAccessException {
						while(rs.next()) {
							
							mpgVoctn.setVocationName(rs.getString("VOC"));
							mpgVoctn.setSrvcIntrvl(rs.getInt("SRVC_INTRV_VAL1"));
						}
						return mpgVoctn;
					}
				});
				
				
			}else if(domicile.equalsIgnoreCase("canada")) {
				jdbcTemplate.query(DBQueries.MPG_VOC_CANADA, new ResultSetExtractor<MpgVoctn>() {

					@Override
					public MpgVoctn extractData(ResultSet rs) throws SQLException, DataAccessException {
						while(rs.next()) {
							MpgVoctn mpgVoctn=new MpgVoctn();
							mpgVoctn.setVocationName(rs.getString("VOC"));
							mpgVoctn.setSrvcIntrvl(rs.getInt("SRVC_INTRV_VAL2"));
						}
						return mpgVoctn;
					}
				});
			}

			return mpgVoctn;
		} catch (Exception e) {
			throw e;
		}
	}

	

}
