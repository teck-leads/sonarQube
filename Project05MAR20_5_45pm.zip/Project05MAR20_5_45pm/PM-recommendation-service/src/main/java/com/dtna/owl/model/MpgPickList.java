package com.dtna.owl.model;

public class MpgPickList extends PickListParent {
	
	
}
