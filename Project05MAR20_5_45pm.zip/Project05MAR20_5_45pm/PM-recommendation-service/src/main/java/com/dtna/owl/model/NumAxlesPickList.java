package com.dtna.owl.model;

public class NumAxlesPickList extends PickListParent{


}
