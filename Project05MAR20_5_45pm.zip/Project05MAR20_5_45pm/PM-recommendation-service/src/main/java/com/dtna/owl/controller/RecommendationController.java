package com.dtna.owl.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dtna.owl.model.RecommdOutput;
import com.dtna.owl.model.RecommendationInput;
import com.dtna.owl.service.RecommendationService;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Controller

public class RecommendationController {

	@Autowired
	private RecommendationService recommendationService;
	
	
	@GetMapping(value = "/recommendations")
	public String loadQuote( Model model) throws Exception {
		
		
		model.addAttribute("engineListKey", recommendationService.getEngineList());
		
		/*
		 * model.addAttribute("modelListKey", recommendationService.getModelList());
		 * model.addAttribute("transmissionListKey",
		 * recommendationService.getTransmissionList());
		 */
		
		model.addAttribute("differentialListKey", recommendationService.getDifferentialList());
		model.addAttribute("vocationListKey", recommendationService.getVoctnPickListList());
		model.addAttribute("mpgListKey", recommendationService.getMpgList());
		model.addAttribute("estimatedServiceIntervalKey", recommendationService.estimatedServiceInterval());
		model.addAttribute("ptoHrsListKey", recommendationService.getPtoHrsList());
		model.addAttribute("planedYrsOfServiceListKey", recommendationService.getPlannedYrsOfServiceList());
		
		model.addAttribute("mviInspectionListKey", recommendationService.getMviInspectionList());
		model.addAttribute("numOfAxlesListKey", recommendationService.getNumOfAxlesList());
		model.addAttribute("numOfWhelSrvcsListKey", recommendationService.getNumWhelSrvcesPickList());
		

		return "quickquote";
		//return "testdb";
	}

	@RequestMapping(value = "/recommendations", method = RequestMethod.POST)
	public String calculatedQuote( @ModelAttribute RecommendationInput recommendationInput, Model model) throws NumberFormatException, Exception {
		
		
		
		//TODO for dropdown
		if(recommendationInput.getEngineFlag().equalsIgnoreCase("yes")) {
			model.addAttribute("engineListKey", recommendationService.getEngineList());
			model.addAttribute("nameKey",recommendationInput.getCustomerName());
			model.addAttribute("engineKey",recommendationInput.getEngine());
			
			RecommendationInput modelList = recommendationService.getModelList(recommendationInput.getEngine());
			model.addAttribute("modelListKey", modelList);
			
			return "quickquote";
		}
		
		if(recommendationInput.getModelFlag().equalsIgnoreCase("yes")) {
			//Engine
			model.addAttribute("engineListKey", recommendationService.getEngineList());
			model.addAttribute("engineKey",recommendationInput.getEngine());
			model.addAttribute("nameKey",recommendationInput.getCustomerName());
			//Model
			model.addAttribute("modelListKey", recommendationService.getModelList(recommendationInput.getEngine()));
			model.addAttribute("modeKey",recommendationInput.getMode());
			//Transition list
			model.addAttribute("transmissionListKey",recommendationService.getTransmissionList(recommendationInput.getMode()));
			
			
			//Set other dropdowns 
			
			model.addAttribute("differentialListKey", recommendationService.getDifferentialList());
			model.addAttribute("vocationListKey", recommendationService.getVoctnPickListList());
			model.addAttribute("mpgListKey", recommendationService.getMpgList());
			
			model.addAttribute("ptoHrsListKey", recommendationService.getPtoHrsList());
			model.addAttribute("planedYrsOfServiceListKey", recommendationService.getPlannedYrsOfServiceList());
			model.addAttribute("mviInspectionListKey", recommendationService.getMviInspectionList());
			model.addAttribute("numOfAxlesListKey", recommendationService.getNumOfAxlesList());
			model.addAttribute("numOfWhelSrvcsListKey", recommendationService.getNumWhelSrvcesPickList());
			
			
			
			
			return "quickquote";
		}
		
		//TODO if VOCATION dropdown value is selected populate MPG and mileage interval
		if(recommendationInput.getMpgFlag().equalsIgnoreCase("yes")) {
			
			//TODO prepare and set the data
			RecommendationInput voctnMpgRecInput = recommendationService.getVoctnMpg(recommendationInput);
			
			model.addAttribute("mileageIntrlKey", voctnMpgRecInput.getMileageInterval());
			/* model.addAttribute("mpgKey",voctnMpgRecInput.getMpg()); */
			
			//model.addAttribute("domicileKey",recommendationInput.getDomicile());
			
			//TODO start Preserve dropdown data
			model.addAttribute("engineListKey", recommendationService.getEngineList());
			
			//dependent of engine
			/*
			 * model.addAttribute("modelListKey", recommendationService.getModelList());
			 * model.addAttribute("transmissionListKey",
			 * recommendationService.getTransmissionList());
			 */
			//dependent of engine
			//Model
			model.addAttribute("modelListKey", recommendationService.getModelList(recommendationInput.getEngine()));
			//model.addAttribute("modeKey",recommendationInput.getMode());
			//Transition list
			model.addAttribute("transmissionListKey",recommendationService.getTransmissionList(recommendationInput.getMode()));
			
			
			
			
			model.addAttribute("differentialListKey", recommendationService.getDifferentialList());
			model.addAttribute("vocationListKey", recommendationService.getVoctnPickListList());
			model.addAttribute("mpgListKey", recommendationService.getMpgList());
			//model.addAttribute("estimatedServiceIntervalKey", recommendationService.estimatedServiceInterval());
			model.addAttribute("ptoHrsListKey", recommendationService.getPtoHrsList());
			model.addAttribute("planedYrsOfServiceListKey", recommendationService.getPlannedYrsOfServiceList());
			model.addAttribute("mviInspectionListKey", recommendationService.getMviInspectionList());
			model.addAttribute("numOfAxlesListKey", recommendationService.getNumOfAxlesList());
			model.addAttribute("numOfWhelSrvcsListKey", recommendationService.getNumWhelSrvcesPickList());
			//TODO end Preserve dropdown data
			
			//TODO Add selected data
			model.addAttribute("nameKey",recommendationInput.getCustomerName());
			model.addAttribute("engineKey",recommendationInput.getEngine());
			model.addAttribute("modeKey",recommendationInput.getMode());
			model.addAttribute("transmissionKey",recommendationInput.getTransmission());
			model.addAttribute("differentialKey",recommendationInput.getDifferential());
			model.addAttribute("ptoHrsKey",recommendationInput.getPtoHrs());
			model.addAttribute("vocationKey",recommendationInput.getVocation());
			model.addAttribute("planedYrsOfServiceKey",recommendationInput.getPlanedYrsOfService());
			model.addAttribute("estimatedAnnualMileageKey",recommendationInput.getEstimatedAnnualMileage());
			
			model.addAttribute("mpgKey",voctnMpgRecInput.getMpg());
			
			return "quickquote";
		}
		
		//TODO if MPG dropdown value is selected 
		if(recommendationInput.getVoctnFlag().equalsIgnoreCase("yes")) {
			RecommendationInput voctnMpg = recommendationService.getVoctnMpg(recommendationInput);
			model.addAttribute("mileageIntrlKey", voctnMpg.getMileageInterval());
			model.addAttribute("vocationKey",voctnMpg.getVocation());
			
			model.addAttribute("engineListKey", recommendationService.getEngineList());
			model.addAttribute("modelListKey", recommendationService.getModelList(recommendationInput.getEngine()));
			model.addAttribute("transmissionListKey",recommendationService.getTransmissionList(recommendationInput.getMode()));
			
			model.addAttribute("differentialListKey", recommendationService.getDifferentialList());
			model.addAttribute("vocationListKey", recommendationService.getVoctnPickListList());
			model.addAttribute("mpgListKey", recommendationService.getMpgList());
			
			model.addAttribute("ptoHrsListKey", recommendationService.getPtoHrsList());
			model.addAttribute("planedYrsOfServiceListKey", recommendationService.getPlannedYrsOfServiceList());
			model.addAttribute("mviInspectionListKey", recommendationService.getMviInspectionList());
			model.addAttribute("numOfAxlesListKey", recommendationService.getNumOfAxlesList());
			model.addAttribute("numOfWhelSrvcsListKey", recommendationService.getNumWhelSrvcesPickList());
			
			model.addAttribute("nameKey",recommendationInput.getCustomerName());
			model.addAttribute("engineKey",recommendationInput.getEngine());
			model.addAttribute("modeKey",recommendationInput.getMode());
			model.addAttribute("transmissionKey",recommendationInput.getTransmission());
			model.addAttribute("differentialKey",recommendationInput.getDifferential());
			model.addAttribute("ptoHrsKey",recommendationInput.getPtoHrs());
			model.addAttribute("planedYrsOfServiceKey",recommendationInput.getPlanedYrsOfService());
			model.addAttribute("estimatedAnnualMileageKey",recommendationInput.getEstimatedAnnualMileage());
			model.addAttribute("mpgKey",recommendationInput.getMpg());
			
			return "quickquote";
			
		}
		
		//get dropdowns 
		
		List<RecommdOutput> calculatedQuote = recommendationService.calculatedQuote(recommendationInput);
		
		List<RecommdOutput> intervalPackage=new ArrayList<RecommdOutput>();
		List<RecommdOutput> annuaLpackage=new ArrayList<RecommdOutput>();
		List<RecommdOutput> addOn=new ArrayList<RecommdOutput>();
		
		calculatedQuote.forEach(rec->{
			if(rec.getSrvcPer().equals("SERVICE INTERVAL")) {
				intervalPackage.add(rec);
			}else if(rec.getSrvcPer().equals("ANNUAL INSPECTION")) {
				annuaLpackage.add(rec);
			}else if(rec.getSrvcPer().equals("ADD ON")) {
				addOn.add(rec);
				
			}
		});
		
		//TODO Add NoOfServices_CalculatedValue and add to Service Interval 
		double nofServices=recommendationService.getIntnlPkgRecmdServices(recommendationInput);
		Integer nofServicesInt=(int)nofServices;
		if(intervalPackage.size()>0) {
			intervalPackage.forEach(rec->{
				rec.setSrvcFreq(String.valueOf(nofServicesInt));
			});
		}
		
		//TODO Preserve dropdown data
		model.addAttribute("engineListKey", recommendationService.getEngineList());
		
		/*
		 * model.addAttribute("modelListKey", recommendationService.getModelList());
		 * model.addAttribute("transmissionListKey",
		 * recommendationService.getTransmissionList());
		 */
		model.addAttribute("modelListKey", recommendationService.getModelList(recommendationInput.getEngine()));
		//model.addAttribute("modeKey",recommendationInput.getMode());
		//Transition list
		model.addAttribute("transmissionListKey",recommendationService.getTransmissionList(recommendationInput.getMode()));
		
		model.addAttribute("differentialListKey", recommendationService.getDifferentialList());
		model.addAttribute("vocationListKey", recommendationService.getVoctnPickListList());
		model.addAttribute("mpgListKey", recommendationService.getMpgList());
		model.addAttribute("estimatedServiceIntervalKey", recommendationService.estimatedServiceInterval());
		model.addAttribute("ptoHrsListKey", recommendationService.getPtoHrsList());
		model.addAttribute("planedYrsOfServiceListKey", recommendationService.getPlannedYrsOfServiceList());
		model.addAttribute("mviInspectionListKey", recommendationService.getMviInspectionList());
		model.addAttribute("numOfAxlesListKey", recommendationService.getNumOfAxlesList());
		model.addAttribute("numOfWhelSrvcsListKey", recommendationService.getNumWhelSrvcesPickList());
		
		//TODO Add selected data
		model.addAttribute("engineKey",recommendationInput.getEngine());
		model.addAttribute("modeKey",recommendationInput.getMode());
		model.addAttribute("transmissionKey",recommendationInput.getTransmission());
		model.addAttribute("differentialKey",recommendationInput.getDifferential());
		model.addAttribute("planedYrsOfServiceKey",recommendationInput.getPlanedYrsOfService());
		model.addAttribute("ptoHrsKey",recommendationInput.getPtoHrs());
		
		model.addAttribute("nameKey",recommendationInput.getCustomerName());
		model.addAttribute("mileageIntrlKey",recommendationInput.getMileageInterval());
		model.addAttribute("estimatedAnnualMileageKey",recommendationInput.getEstimatedAnnualMileage());
		model.addAttribute("mpgKey",recommendationInput.getMpg());
		model.addAttribute("vocationKey",recommendationInput.getVocation());
		
		
		
		//TODO right side screen data
		 model.addAttribute("intervalKey", intervalPackage); 
		 model.addAttribute("annuaLpackageKey", annuaLpackage);
		 model.addAttribute("addOnKey", addOn);

	return "quickquote";
		 //return "redirect:/recommendations";
	}
	
	
	
	
	@RequestMapping(value = "/vocation", method = RequestMethod.GET)
	public @ResponseBody String getSector(@RequestParam("vocId")String vocId) throws JsonGenerationException, JsonMappingException, IOException
	{
	  return "ajax response ----"+vocId;
	}

}
