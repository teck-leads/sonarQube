package com.dtna.owl.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VoctnMpg {
	private Double mpgVal1;
	private Integer srvcIntrvl1;
	private Double mpgVal2;
	private Integer srvcIntrvl2;
	

}
