package com.dtna.owl.model;

public class PtoHrsPickList extends PickListParent{

	
}

