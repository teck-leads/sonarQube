package com.dtna.owl.model;

public class ModelPickList extends PickListParent {
	
	

}
