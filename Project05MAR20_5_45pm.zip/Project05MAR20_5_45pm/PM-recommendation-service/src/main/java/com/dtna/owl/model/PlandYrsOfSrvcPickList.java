package com.dtna.owl.model;

public class PlandYrsOfSrvcPickList extends PickListParent{

	
}
