package com.dtna.owl.model;

public class NumWhelSrvcesPickList extends PickListParent {
	
}
