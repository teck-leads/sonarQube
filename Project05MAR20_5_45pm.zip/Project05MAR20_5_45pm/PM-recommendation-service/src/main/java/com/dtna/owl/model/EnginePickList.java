package com.dtna.owl.model;

public class EnginePickList extends PickListParent{
	

}

