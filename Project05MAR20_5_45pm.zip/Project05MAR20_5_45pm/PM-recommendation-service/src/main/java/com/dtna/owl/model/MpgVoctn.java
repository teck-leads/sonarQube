package com.dtna.owl.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MpgVoctn {
	private String vocationName;
	private Integer srvcIntrvl;

}
