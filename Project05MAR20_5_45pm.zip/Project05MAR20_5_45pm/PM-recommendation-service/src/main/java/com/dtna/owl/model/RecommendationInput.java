package com.dtna.owl.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecommendationInput {

	private String customerName;
	private String domicile;

	
	private List<EnginePickList> engpckList;
	private List<ModelPickList> modepcklList;
	private List<TranMsnPickList> tranMsnpcklList;
	private List<DifntlPickList> difntlpckList;
	private List<VoctnPickList> vocationpckList;
	
	
	private List<MpgPickList> mpgList;
	private Integer mileageInterval;
	private String estimatedAnnualMileage;
	private List<PtoHrsPickList> ptoHrsList;
	private List<PlandYrsOfSrvcPickList> planedYrsOfSrvcList;
	
	
	private List<MviInspePickList> mviInspectionList;
	private List<NumAxlesPickList> numOfAxlesList;
	private List<NumWhelSrvcesPickList> numOfServicesList;

	private String engine;
	private String mode;
	private String transmission;
	private String differential;
	private String vocation;
	private String mpg;
	private String ptoHrs;
	private String planedYrsOfService;
	private String mviInspection;
	private String numOfAxles;
	private String numOfServices;
	private String comments;
	private String mpgFlag;
	private String voctnFlag;
	private String engineFlag;
	private String modelFlag;

}
