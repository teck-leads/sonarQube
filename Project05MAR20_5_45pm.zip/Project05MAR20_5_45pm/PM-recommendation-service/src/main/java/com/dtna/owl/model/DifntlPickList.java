package com.dtna.owl.model;

public class DifntlPickList extends PickListParent {

	
	
}


