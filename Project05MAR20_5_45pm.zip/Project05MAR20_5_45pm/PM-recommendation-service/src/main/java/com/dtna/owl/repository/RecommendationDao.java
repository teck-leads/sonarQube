package com.dtna.owl.repository;

import java.util.List;

import com.dtna.owl.model.ConversionRate;
import com.dtna.owl.model.DifntlPickList;
import com.dtna.owl.model.EnginePickList;
import com.dtna.owl.model.ModelPickList;
import com.dtna.owl.model.MpgPickList;
import com.dtna.owl.model.MpgVoctn;
import com.dtna.owl.model.MviInspePickList;
import com.dtna.owl.model.NumAxlesPickList;
import com.dtna.owl.model.NumWhelSrvcesPickList;
import com.dtna.owl.model.PickListParent;
import com.dtna.owl.model.PlandYrsOfSrvcPickList;
import com.dtna.owl.model.PtoHrsPickList;
import com.dtna.owl.model.RecommdOutput;
import com.dtna.owl.model.RecommendationInput;
import com.dtna.owl.model.TranMsnPickList;
import com.dtna.owl.model.VoctnMpg;
import com.dtna.owl.model.VoctnPickList;

public interface RecommendationDao {
	
	public List<EnginePickList> getEngineList() throws Exception;
	public List<ModelPickList> getModelList(String engine) throws Exception;
	public List<TranMsnPickList> getTranMsnList(String modelValue) throws Exception;
	public List<DifntlPickList> getDifntlList() throws Exception;
	public List<VoctnPickList> getVoctnPickListList() throws Exception;
	public List<MpgPickList> getMpgPickListList() throws Exception;
	public List<PtoHrsPickList> getPtoHrsPickListList() throws Exception;
	public List<PlandYrsOfSrvcPickList> getPlndYrsOfSrvcPickListList() throws Exception;
	
	public List<MviInspePickList> getMviInspePickList() throws Exception;
	public List<NumAxlesPickList> getNumAxlesPickList() throws Exception;
	public List<NumWhelSrvcesPickList> getNumWhelSrvcesPickList() throws Exception;
	
	public List<RecommdOutput> getRecommdOutput(String bseMdlCde, int servIntervl, int srvcYr )throws Exception;
	
	public VoctnMpg getVoctnMpg(String baseMdlCd, String voctn)throws Exception;
	public MpgVoctn getMpgVoctn(String baseMdlCd, String mpgval, String domicile) throws Exception;
	
	ConversionRate getConvertionRate(RecommendationInput recommendationInput)throws Exception;
	public  List<PickListParent> getAllPickList() throws Exception;
	
	

}
