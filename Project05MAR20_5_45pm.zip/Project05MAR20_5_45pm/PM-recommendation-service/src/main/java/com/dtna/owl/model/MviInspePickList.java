package com.dtna.owl.model;

public class MviInspePickList extends PickListParent {
	

	
}
