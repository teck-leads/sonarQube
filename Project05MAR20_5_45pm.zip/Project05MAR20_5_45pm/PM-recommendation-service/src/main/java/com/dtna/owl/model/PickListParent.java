package com.dtna.owl.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PickListParent {
	private String value;
	private String desc;
	private String lkpTyp;
	private String parentTyp;

}
