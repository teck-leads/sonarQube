package com.dtna.owl.model;

public class TranMsnPickList extends PickListParent{
	

}


