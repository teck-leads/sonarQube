package com.dtna.owl.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dtna.owl.model.ConversionRate;
import com.dtna.owl.model.DifntlPickList;
import com.dtna.owl.model.EnginePickList;
import com.dtna.owl.model.ModelPickList;
import com.dtna.owl.model.MpgPickList;
import com.dtna.owl.model.MpgVoctn;
import com.dtna.owl.model.MviInspePickList;
import com.dtna.owl.model.NumAxlesPickList;
import com.dtna.owl.model.NumWhelSrvcesPickList;
import com.dtna.owl.model.PlandYrsOfSrvcPickList;
import com.dtna.owl.model.PtoHrsPickList;
import com.dtna.owl.model.RecommdOutput;
import com.dtna.owl.model.RecommendationInput;
import com.dtna.owl.model.TranMsnPickList;
import com.dtna.owl.model.VoctnMpg;
import com.dtna.owl.model.VoctnPickList;
import com.dtna.owl.repository.RecommendationDao;

@Service
public class RecommendationService {
	@Autowired
	private RecommendationDao recommendationDao;
	
	
	public RecommendationInput getEngineList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		List<EnginePickList> enginePckList = recommendationDao.getEngineList();
		recommendationInput.setEngpckList(enginePckList);
		return recommendationInput;
	}
	

	public RecommendationInput getModelList(String engine) throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		
		List<ModelPickList> modePcklList = recommendationDao.getModelList(engine);
//		List<String> engineList = Arrays.asList("Cascadia", "Cascadia 113", "Cascadia 116", "Cascadia 125", "Coronado",
//				"Econic", "M2 106", "M2 112", "New Cascadia 126", "SD 108", "SD 114", "SD 122", "WS 4700", "WS 4800",
//				"WS 4900", "WS 5700", "WS 6900");

		
		recommendationInput.setModepcklList(modePcklList);
		return recommendationInput;

	}

	public RecommendationInput getTransmissionList(String modelValue) throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		List<TranMsnPickList> tranMsnList = recommendationDao.getTranMsnList(modelValue);
		recommendationInput.setTranMsnpcklList(tranMsnList);
		return recommendationInput;

	}

	public RecommendationInput getDifferentialList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		List<DifntlPickList> difntlList = recommendationDao.getDifntlList();
		recommendationInput.setDifntlpckList(difntlList);

		return recommendationInput;

	}


	public RecommendationInput getVoctnPickListList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		 List<VoctnPickList> voctnPickList = recommendationDao.getVoctnPickListList();
		recommendationInput.setVocationpckList(voctnPickList);
		return recommendationInput;
		
	}
	

	public RecommendationInput getMpgList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
//		List<String> mpgList = Arrays.asList("Less Than 10.0", "10.1 to 11.9", "Greater than 12.0", "Less than 6.5",
//				"6.5 to 8.5", "Less than 5.0", "5.1 to 5.9", "6.0 to 6.9", "Greater than 7.0", "Less than 5.0");
		
		List<MpgPickList> mpgPickListList = recommendationDao.getMpgPickListList();
		recommendationInput.setMpgList(mpgPickListList);

		return recommendationInput;

	}

	public RecommendationInput getPtoHrsList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		List<PtoHrsPickList> ptoHrsPickListList = recommendationDao.getPtoHrsPickListList();
		recommendationInput.setPtoHrsList(ptoHrsPickListList);
		return recommendationInput;

	}

	public RecommendationInput getPlannedYrsOfServiceList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		List<PlandYrsOfSrvcPickList> plndYrsOfSrvcPickListList = recommendationDao.getPlndYrsOfSrvcPickListList();
		recommendationInput.setPlanedYrsOfSrvcList(plndYrsOfSrvcPickListList);
		return recommendationInput;

	}

	public RecommendationInput getMviInspectionList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		List<MviInspePickList> mviInspePickList = recommendationDao.getMviInspePickList();
		recommendationInput.setMviInspectionList(mviInspePickList);
		return recommendationInput;

	}

	public RecommendationInput getNumOfAxlesList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		List<NumAxlesPickList> numAxlesPickList = recommendationDao.getNumAxlesPickList();
		recommendationInput.setNumOfAxlesList(numAxlesPickList);

		
		return recommendationInput;

	}

	
	public RecommendationInput getNumWhelSrvcesPickList() throws Exception {
		RecommendationInput recommendationInput = new RecommendationInput();
		List<NumWhelSrvcesPickList> numWhelSrvcesPickList = recommendationDao.getNumWhelSrvcesPickList();
		recommendationInput.setNumOfServicesList(numWhelSrvcesPickList);
		return recommendationInput;

	}
	
	public RecommendationInput estimatedServiceInterval() {
		RecommendationInput recommendationInput = new RecommendationInput();
		recommendationInput.setMileageInterval(null);
		return recommendationInput;

	}
	public List<RecommdOutput> calculatedQuote(RecommendationInput recommendationInput) throws NumberFormatException, Exception {
		
		String baseModelCde = recommendationInput.getEngine();
		String estimatedAnnualMileage = recommendationInput.getEstimatedAnnualMileage();
		String planedYrsOfService = recommendationInput.getPlanedYrsOfService();
		
		List<RecommdOutput> recommdOutput = recommendationDao.getRecommdOutput(baseModelCde, Integer.parseInt(estimatedAnnualMileage), Integer.parseInt(planedYrsOfService));
		
		
		return recommdOutput;
		
	}
	
	public RecommendationInput getVoctnMpg(RecommendationInput recommendationInput) throws Exception{
		try {
			VoctnMpg voctnMpg = recommendationDao.getVoctnMpg(recommendationInput.getEngine(), recommendationInput.getVocation());
			if(recommendationInput.getDomicile().equalsIgnoreCase("usa")) {
				recommendationInput.setMileageInterval(voctnMpg.getSrvcIntrvl1());
				recommendationInput.setMpg(String.valueOf(voctnMpg.getMpgVal1()));
			}else if(recommendationInput.getDomicile().equalsIgnoreCase("canada")) {
				recommendationInput.setMileageInterval(voctnMpg.getSrvcIntrvl2());
				recommendationInput.setMpg(String.valueOf(voctnMpg.getMpgVal2()));
			}
			
			return recommendationInput;
		} catch (Exception e) {
			throw e;
		}
	}
	
	public RecommendationInput getMpgVoctn(RecommendationInput recommendationInput) throws Exception{
		try {
		 MpgVoctn mpgVoctn = recommendationDao.getMpgVoctn(recommendationInput.getEngine(), recommendationInput.getMpg(), recommendationInput.getDomicile());
				recommendationInput.setMileageInterval(mpgVoctn.getSrvcIntrvl());
				recommendationInput.setVocation(mpgVoctn.getVocationName());
			return recommendationInput;
		} catch (Exception e) {
			throw e;
		}
	}
	public double getIntnlPkgRecmdServices(RecommendationInput recommendationInput) throws Exception {
		try {
			Integer estimatedAnnualMileage = Integer.parseInt(recommendationInput.getEstimatedAnnualMileage());
			Integer conversnRate=0;
			Integer ptoHrs = Integer.parseInt(recommendationInput.getPtoHrs());
			
			Integer planedYrsOfService = Integer.parseInt(recommendationInput.getPlanedYrsOfService());
			Integer mileageInterval = recommendationInput.getMileageInterval();
			
			//TODO getConversion Rate
			ConversionRate conversionRate=recommendationDao.getConvertionRate(recommendationInput);
			if(recommendationInput.getDomicile().equalsIgnoreCase("usa")) {
				conversnRate = conversionRate.getPtoCnvrtVal1Usa();
			}else if(recommendationInput.getDomicile().equalsIgnoreCase("canada")) {
				conversnRate = conversionRate.getPtoCnvrtVal2Canada();
			}
			double totalMileage=((estimatedAnnualMileage+(ptoHrs*conversnRate))*planedYrsOfService);
			double numOfServices=totalMileage/mileageInterval;
			
			
			return numOfServices;
		} catch (Exception e) {
			throw e;
		}
		
	}
	
	
	 

}
