package com.dtna.owl.model;

public class VoctnPickList extends PickListParent{
	

}
